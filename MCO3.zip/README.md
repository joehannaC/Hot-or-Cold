# CCAPDEV MCO
- Welcome to our forum app, HotOrCold! 
- This app inspired by Reddit, but instead of upvote and downvote, it's Hot or Cold!

# Setting up the program
- Make sure to install all the necessary node packages in your machine, you can use ```npm install <package>``` or ```npm i <package>```
- Run the application on your machine's terminal and use the command ```node index.js``` or ```npm run MCO```
- To access the app locally, enter http://localhost:3000 at your browser,
- Or you can visit our website at https://hotorcoldforum.onrender.com/!